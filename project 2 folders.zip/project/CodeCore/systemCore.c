#include "../include/core/systemCore.h"

#include "../CodeP1/datetime.c"
#include "../CodeP1/airport.c"
#include "../CodeP1/flight.c"
#include "../CodeP1/flightManipulators.c"
#include "../CodeP2/reservationsManipulators.c"
#include "../CodeP2/eliminator.c"

int SystemStartAndInitializer(){
    int SystemDate = DateTimeToTimeStamp(2022,1,1,0,0,0);
    Airport SystemAirports[MAX_AIRPORTS];
    Flight SystemFlights[MAX_FLIGHTS];

    SystemLoop(SystemAirports,SystemFlights,SystemDate);

    return 0;
}

int SystemLoop(Airport SystemAirportsST[],Flight SystemFlightsST[],int SystemDate){
    unsigned char command;
    unsigned int airport_count = 0,flight_count = 0;

    while ((command = getchar()))
    {
        switch (command){
        case 'a':   /*  Adds New Airport  */
            airport_count += AirportAdder(SystemAirportsST,airport_count);
            break;
        case 'l':   /*  List Airports Recorded  */
            ListAirport(SystemAirportsST,airport_count);
            break;
        case 'v':   /*  Adds New Flight  */
            flight_count += FlightAdder(SystemAirportsST,SystemFlightsST,SystemDate,
                                airport_count,flight_count);
            break;
        case 'p':    /*  Lists Flights Departing from an Airport  */
            ListDepartingOrArrivingFlights(SystemAirportsST,SystemFlightsST,
                airport_count,flight_count,'d');
            break;
        case 'c':   /*  lists flights Arriving at an airport  */
            ListDepartingOrArrivingFlights(SystemAirportsST,SystemFlightsST,
                airport_count,flight_count,'a');
            break;
        case 't':   /*  Advance the System Date  */
            SystemDate = DateAdvancer(SystemDate);
            break;
        case 'r':   /*  Adds Reservation  */
            ReservationAdder(SystemFlightsST,flight_count,
                                    SystemDate);
            break;
        case 'e':   /*  Advance the System Date  */
            flight_count = (unsigned int)SystemEliminator(SystemFlightsST,flight_count);
            break;
        case 'q':   /*  Advance the System Date  */
            SystemTerminate(SystemFlightsST,flight_count);
            break;
        default:
            break;
        }
    }
  return 0;
}

void SystemCleanUp(Flight SystemFlightsST[],uint flight_count){
    uint counter;
    for (counter = 0; counter < flight_count; counter++){
        deleteList(SystemFlightsST[counter].flight_reservations);
    }
}

void SystemTerminate(Flight SystemFlightsST[],uint flight_count){
    SystemCleanUp(SystemFlightsST,flight_count);
    exit(0);
}

void *MemoryChecker(void *mallocVal){
    if (!mallocVal){
        printf("No memory.\n");
    }
    return mallocVal;
}
