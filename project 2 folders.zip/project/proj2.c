/*
 * File:    proj1.c
 * Author:  Daniel Martins Pão Alvo (ist1102914)
 * Email:   daniel.martins.22@tecnico.ulisboa.pt
 * Description: An attempt at making an airport and flight management system.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "CodeCore/systemCore.c"

int main(){
    SystemStartAndInitializer();
    return 0;
}
