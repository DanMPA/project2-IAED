#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "../include/p1/dateTime.h"
#include "../include/core/systemCore.h"
#include "../include/p1/airport.h"
#include "../include/p1/bool.h"
#include "../include/p1/flight.h"
#include "../include/p2/reservation.h"


int FlightRemover(Flight FlightST[],char code[],int flight_count){
    int index,counter;
    counter = 0;

    for (index = 0; index < flight_count; index++){
        if(!strcmp(FlightST[index].flight_code,code)){
            counter +=1;
        } else{
            FlightST[index - counter] = FlightST[index]; 
        }
    }
    if(!counter){
        printf("not found\n");
        return flight_count;
    } else {
        return flight_count - counter;
    }
}
void ReservationRemover(Flight FlightST[],char code[],int flight_count){
    int index; 
    for (index = 0; index < flight_count;index++){
        if(lookup(&FlightST[index].flight_reservations,code)){
            deleteList(FlightST[index].flight_reservations);
            FlightST[index].flight_reservations = NULL;
            return;
        }
    }
    printf("not found\n");
}

int SystemEliminator(Flight FlightST[],unsigned int flight_count){
    char temp_Code[MAX_INPUT];
    int len_code;

    scanf("%s",temp_Code);
    len_code = strlen(temp_Code);
    if(len_code <= 7){
        flight_count = FlightRemover(FlightST,temp_Code,flight_count);
        return flight_count;
    } else{
        ReservationRemover(FlightST,temp_Code,flight_count);
    }
    return flight_count;
}
