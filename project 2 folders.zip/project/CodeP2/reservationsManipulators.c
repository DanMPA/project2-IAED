#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "../include/core/systemCore.h"
#include "../include/p1/airport.h"
#include "../include/p1/bool.h"
#include "../include/p1/dateTime.h"
#include "../include/p1/flight.h"

#include "../include/p2/reservation.h"

Reservation *newReservation(char code[],uint numberOfPassangers){
    /* Allocating memory */
    Reservation *nReservation = MemoryChecker(malloc(sizeof(struct node)));
    nReservation->code = MemoryChecker(malloc(sizeof(char)*(strlen(code)+1)));

    /* Copping over information */
    strcpy(nReservation->code,code);
    nReservation->numPassangers = numberOfPassangers;

    return nReservation; 
}

LinkList newLink(Reservation * reservation){
    /* Allocating memory */
    LinkList nReservation = MemoryChecker(malloc(sizeof(struct node)));
    nReservation->reservation.code = reservation->code;
    nReservation->reservation.numPassangers = reservation->numPassangers;

    nReservation->next = NULL;
    return nReservation; 
}

void FreeNode(LinkList head){
    free(head->reservation.code);
    free(head);
}

LinkList lookup(LinkList *head, char code[]){
    LinkList temp;
    for (temp = *head; temp != NULL; temp=temp->next){
        if(!strcmp(temp->reservation.code,code)){
            return temp;
        }
    }
    return NULL;
}

void delete(LinkList *head,Reservation reservation){
    LinkList temp, prev;
    for (temp = *head, prev = NULL; temp != NULL;prev = temp, temp=temp->next){
        if (!strcmp(temp->reservation.code,reservation.code)){
            if(temp == *head){
                *head = temp->next;
            } else{
                prev->next = temp->next;
            }
            FreeNode(temp);
        }
    }
}

void deleteList(LinkList head){
    LinkList temp;
    while (head != NULL){
        temp = head;
        head = head->next;
        FreeNode(temp);
    }
    free(head);
} 

void sortedInsert(LinkList *sorted,Reservation *reservation){
    LinkList newnode,temp;
    newnode = newLink(reservation);
    temp = *sorted;

    /* Special case for the head end */
    if (sorted == NULL || 
        strcmp(temp->reservation.code,newnode->reservation.code) >= 0) {
        newnode->next = temp;
        *sorted = newnode;
    }else {
        LinkList current = *sorted;
        /* Locate the node before the point of insertion*/
        while (current->next != NULL && 
            strcmp(current->next->reservation.code,newnode->reservation.code) < 0) {
            current = current->next;
        }
        newnode->next = current->next;
        current->next = newnode;
    }
}

/* Reservations */
int E_ValidReservationCode(char reservation_code[]){
    int counter,code_length;
    code_length = strlen(reservation_code);
    if(code_length < RESERVATION_CODE_LEN){
        printf("invalid reservation code\n");
        return FALSE;
    }
    for (counter = 0; counter < code_length; counter++){
        if(isalnum(reservation_code[counter])){
            if(!isnumber(reservation_code[counter])){
                if(!isupper(reservation_code[counter])){
                    printf("invalid reservation code\n");
                    return FALSE;
                }
            }
        }else{
            printf("invalid reservation code\n");
            return FALSE;
        }
    }
    return TRUE;
}

int E1_FlightExists(Flight FlightsST[],char flight_code[],uint date,uint flight_count){
    if(FlightFinderDate(FlightsST,flight_code,date,flight_count) == -1){
        printf("%s: flight does not exist\n",flight_code);
        return TRUE;
    }
    return FALSE;
}

int E_ReservationExists(Flight FlightsST[],int flight_count,char reservation_code[]){
    LinkList temp;
    int index;
    
    for(index = 0; index < flight_count;index++){
        temp = lookup(&FlightsST[index].flight_reservations,reservation_code);
        if(temp){
        printf("%s: flight reservation already used\n",reservation_code);
        return TRUE;
        }
    }
    return FALSE;
}

int E_ReservationCapacityLimit(Flight FlightsST[],int flight_index,int reservation_capacity){
    if((FlightsST[flight_index].reservation_capacity + reservation_capacity) 
        > FlightsST[flight_index].flight_capacity){
        printf("too many reservations\n");
        return TRUE;
    }
    return FALSE;
}

int E_ValidReservationDate(uint current_date,uint reservation_date){
    if(current_date > reservation_date || 
        reservation_date >= reservation_date+SEC_IN_YEAR){
            printf("invalid date\n");
            return FALSE;
        }
    return TRUE;
}

int E_ValidReservationCapacity(int reservation_capacity){
    if(reservation_capacity <= 0){
        printf("invalid passenger number\n");
        return FALSE;
    }
    return TRUE;
}

int GenericReservationErrorFunctions(Flight FlightsST[],
        int flight_index,char flight_code[],uint flight_count,uint flight_date,
        char reservation_code[],int reservation_capacity,
        uint system_date){

    if(E_ValidReservationCode(reservation_code) &&
       !E1_FlightExists(FlightsST,flight_code,flight_date,flight_count) &&
       !E_ReservationExists(FlightsST,flight_index,reservation_code) &&
       E_ValidReservationCapacity(reservation_capacity) &&
       !E_ReservationCapacityLimit(FlightsST,flight_index,reservation_capacity) &&
       E_ValidReservationDate(system_date,flight_date)){
           return TRUE;
    }
    return FALSE;
}
 
void PrintReservation(LinkList *head){
    LinkList temp;
    for(temp = *head; temp != NULL; temp = temp->next){
        printf("%s %d\n",temp->reservation.code,temp->reservation.numPassangers);
    }
}

int ReservationAdder(Flight FlightsST[],int flight_count,uint current_date){

    int day,month,year,flight_index;
    int temp_reservation_capacity;
    char temp_flight_code[FLIGHT_CODE], temp_reservation_code[MAX_INPUT];
    int date;

    Reservation * temp_reservation;
    LinkList temp_link;

    scanf("%s %d-%d-%d",temp_flight_code,&day,&month,&year);

    date = DateTimeToTimeStamp(year,month,day,0,0,0);
    flight_index = FlightFinderDate(FlightsST,temp_flight_code,date,flight_count);
  
    if((getchar()) == '\n'){
        if(E_ValidReservationDate(current_date,date)){
            PrintReservation(&FlightsST[flight_index].flight_reservations);
        }
        return 0;
    }
    scanf("%s %d",temp_reservation_code,&temp_reservation_capacity);

    if(GenericReservationErrorFunctions(FlightsST,flight_index,temp_flight_code,
        flight_count,date,temp_reservation_code,temp_reservation_capacity,
        current_date)){

        temp_reservation = newReservation(temp_reservation_code,temp_reservation_capacity);
    
        if(!FlightsST[flight_index].flight_reservations){
            temp_link = newLink(temp_reservation);
            FlightsST[flight_index].flight_reservations = temp_link;
            FlightsST[flight_index].reservation_capacity += temp_reservation_capacity;
        } else if(FlightsST[flight_index].flight_reservations){
            sortedInsert(&FlightsST[flight_index].flight_reservations,temp_reservation);
            FlightsST[flight_index].reservation_capacity += temp_reservation_capacity;
            FlightsST[flight_index].reservation_count += 1;
        }
        return 1;
    }
    return 0;
}


