/*-*-coding:utf-8 -*- 
 *Auto updated?
 *   Yes
 *File :
 *   flight.h
 *Author :
 *   Daniel Martins Pão Alvo
 * 
 *Created:
 *   April 9, 2022, 11:22:16 PM GMT+1
 *Last edited:
 *   April 18, 2022, 3:19:00 PM GMT+1
 *
 *Description:
 *   Definations of a Flight and respective auxiliary functions.
 *
 *Dependencies:
 *   "airport.h"
**/

#include "airport.h"
#include "../p2/reservation.h"

#define FLIGHT_CODE 7

#define VALID_FLIGHT_DURATION 12
#define FLIGHT_CAPACITY_MIN 10
#define FLIGHT_CAPACITY_MAX 100

#define MAX_FLIGHTS 30000

#ifndef Flight_H
#define Flight_H

/* 32bytes */
typedef struct Flight {
    char flight_code[FLIGHT_CODE];
    char airport_departure[AIRPORT_ID];
    char airport_arrival[AIRPORT_ID];
    unsigned int date;
    unsigned int datetime;
    unsigned int flight_duration;
    unsigned int flight_capacity;

    unsigned int reservation_capacity;
    unsigned int reservation_count;
    LinkList flight_reservations;
}Flight;

/* 
 *          Flight Error Functions.
*/

/* E_FlightCodeVerifer
 *  ~ Verifies if valid flight code. 
 * Args:
 *       ~ flight_code(pointer char): Flight code. 
 * Raises:
 *       ~ "invalid flight code": If Flight code not composed of three uppercase
 *          letter and any trailing number between and including 1-9999.
 * Returns:
 *       ~ (int): If valid returns 1, else 0.
 */
int E_FlightCodeVerifer(char flight_code[]);

/* E_FlightExists
 *  ~ Verifies if valid flight code. 
 * Args:
 *       ~ FlightST(pointer struct flight): Array where flight are stored.
 *       ~ flight_code(pointer char): Flight code. 
 *       ~ date_ref(unsigned int): Flight date. 
 *       ~ flight_count(int): Number of flights in system. 
 * Raises:
 *       ~ "flight already exists": If flight has the same day as an exist flight
 *         in the system.
 * Returns:
 *       ~ (int): If valid returns 1, else 0.
 */
int E_FlightExists(Flight FlightST[],char flight_code[],unsigned int date_ref,
    int flight_count);

/* E_ValidAirport
 *  ~ Verifies if Airport exist in system. 
 * Args:
 *       ~ AirportST(pointer struct Airport): Array where airports are stored.
 *       ~ id(pointer char): Airport ID.
 *       ~ airport_count(int): Number of airports in system.
 * Raises:
 *       ~ "no such airport ID": If airport does not exit in system.
 * Returns:
 *       ~ (int): If valid returns 1, else 0.
 */
int E_ValidAirport(Airport AirportST[],char airport_ID[],int airport_count);

/* E_MAXFlights
 *  ~ Verifies if valid flight code. 
 * Args:
 *       ~ flight_count(int): Number of flights in system. 
 * Raises:
 *       ~ "too many flights": If number of flights excedes max declared. 
 * Returns:
 *       ~ (int): If valid returns 1, else 0.
 */
int E_MAXFlights(int flight_count);


int E_ValidFlightDate(unsigned int current_date,unsigned int date_ref);

int E_ValidDuration(unsigned int duration);

int E_ValidCapacity(unsigned int capacity);

int GenericFlightErrorHandler(Airport AirportST[], Flight FlightST[],char temp_flight_code[],
    unsigned int temp_datetime_ref,unsigned int temp_duration_ref,unsigned int flight_count,
    unsigned int airport_count,char temp_airport_departure[],char temp_airport_arrival[],
    unsigned int current_date, unsigned int temp_capacity);

void FlightPrinter(Flight FlightST);

int FlightFinderDate(Flight SystemFlightsST[],char flight_code[],unsigned int date,unsigned int flight_count);

void ListFlights(Flight FlightST[],unsigned int flight_count);

int FlightAdder(Airport AirportST[], Flight FlightST[],unsigned int current_date,
    unsigned int airport_count,unsigned int flight_count);

#endif /* Flight_H */
