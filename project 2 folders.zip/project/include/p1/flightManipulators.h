/*-*-coding:utf-8 -*- 
 *Auto updated?
 *   Yes
 *File :
 *   flightManipulators.h
 *Author :
 *   Daniel Martins Pão Alvo
 *
 *Created:
 *   April 9, 2022, 11:23:37 PM GMT+1
 *Last edited:
 *   April 16, 2022, 6:34:53 PM GMT+1
 *
 *Description:
 *   Definitions of functions for manipulating flights.
 *
 *Dependencies:
 *   "airport.h"
 *   "flight.h"
**/

#include "airport.h"
#include "flight.h"

int AirportIDFinder(Airport AirportST[],char airport_id[],
        unsigned int airport_count);
void SwapFlights(Flight *FlightST1, Flight *FlightST2);
void DepartingFlightsSorter(Flight FlightST[], int num_flights);
void ArrivingFlightsSorter(Flight arr[], int n);
void FlightListSelector(Flight FlightST[],Flight TempFlightST[],
        unsigned int flight_count,char airport_id[], char flag);
void ListDepartingOrArrivingFlights(Airport AirportST[],Flight FlightST[],
        unsigned int airport_count, int flight_count,char flag);
