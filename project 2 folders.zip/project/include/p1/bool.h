/*-*-coding:utf-8 -*- 
 *Auto updated?
 *   Yes
 *File :
 *   bool.h
 *Author :
 *   Daniel Martins Pão Alvo
 *
 *Created:
 *   April 9, 2022, 11:20:40 PM GMT+1
 *Last edited:
 *   April 16, 2022, 6:34:24 PM GMT+1
 *
 *Description:
 *   Definition of basic Bool. 
 *
 *Dependencies:
 *   <None>
**/

/* Definition of bool.*/
#define TRUE 1
#define FALSE 0
