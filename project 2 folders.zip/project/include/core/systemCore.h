/*-*-coding:utf-8 -*- 
 *Auto updated?
 *   Yes
 *File :
 *   systemMain.h
 *Author :
 *   Daniel Martins Pão Alvo
 * 
 *Created:
 *   April 9, 2022, 11:25:33 PM GMT+1
 *Last edited:
 *   April 18, 2022, 10:46:33 AM GMT+1
 *
 *Description:
 *   Definitions of functions for system initialise and continuation work.
 *
 *Dependencies:
 *   "airport.h"
 *   "flight.h"
**/

#include "../p1/airport.h"
#include "../p1/flight.h"

/* SystemLoop
 *  ~ Main function reponsible for protestant system loop, 
 *    calling action functions and terminating procces. 
 * Args:
 *       ~ AirportsST(struct Airports): A pointer to a Structor of Airports 
 *       ~ FlightsST(struct Flights): A pointer to a Structor of Flights
 *       ~ SystemDate(int SystemDate): A integer representing the date time. 
 * Returns:
 *       ~ (int): Returns 0 to indicate loop termination.
 */
int SystemLoop(Airport AirportsST[],Flight FlightsST[],int SystemDate);

/* SystemLoop
 *  ~ Initializes system critical variables and calls main loop.
 * Args:
 *       ~ <None>
 * Returns:
 *       ~ (int): Returns 0 to indicate termination of proccess.
 */
int SystemStartAndInitializer();


void *MemoryChecker(void *mallocVal);

void SystemTerminate();
