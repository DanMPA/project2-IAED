/*-*-coding:utf-8 -*- 
 *Auto updated?
 *   Yes
 *File :
 *   reservation.h
 *Author :
 *   Daniel Martins Pão Alvo
 *Created:
 *   April 13, 2022, 3:42:43 PM GMT+1
 *Last edited:
 *   April 18, 2022, 2:55:04 PM GMT+1
 *
 *Description:
 *   Definitions of reservations and respective auxiliary functions.
 *
 *Dependencies:
 *   <None>
**/

#define RESERVATION_CODE_LEN 10
#define MAX_INPUT 65536

#ifndef Reservations_H
#define Reservations_H

typedef struct reservation{
    char *code;
    unsigned int numPassangers;
} Reservation;

/* Link list */
typedef struct node{
    Reservation reservation;
    struct node *next;  
} *LinkList;

Reservation *newReservation(char code[],unsigned int numberOfPassangers);
LinkList newLink(Reservation * reservation);
void FreeNode(LinkList head);
LinkList lookup(LinkList *head, char code[]);
void insertBeginning(LinkList *head, Reservation *reservation);
void insertEnd(LinkList *head,Reservation *reservation);
void delete(LinkList *head,Reservation reservation);
void deleteList(LinkList head);
void printList(LinkList *head);

#endif /* Reservations_H */
