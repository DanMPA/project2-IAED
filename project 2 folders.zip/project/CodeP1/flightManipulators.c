#include "../include/p1/flightManipulators.h"

/* ------- Flight Functions ------- */

int AirportIDFinder(Airport AirportST[],char airport_id[],
        unsigned int airport_count){
    unsigned int counter;
    for (counter = 0; counter < airport_count; counter++){
        if(!strcmp(AirportST[counter].id,airport_id)){
            return counter;
        }
    }
    printf("%s: no such airport ID\n",airport_id);
    return -1;
}

void SwapFlights(Flight *FlightST1, Flight *FlightST2){
    Flight temp = *FlightST1;
    *FlightST1 = *FlightST2;
    *FlightST2 = temp;
}

void DepartingFlightsSorter(Flight FlightST[], int num_flights){
    int i, j;
     for (i = 0; i < num_flights-1; i++){     
        for (j = 0; j < num_flights-i-1; j++){
            if ((FlightST[j].datetime) > 
                (FlightST[j+1].datetime)){
                SwapFlights(&FlightST[j], &FlightST[j+1]);
            }
        }
    }
}

void ArrivingFlightsSorter(Flight arr[], int n){
   int i, j;
   for (i = 0; i < n-1; i++)     
       for (j = 0; j < n-i-1; j++)
           if ((arr[j].datetime + arr[j].flight_duration) > 
           (arr[j+1].datetime + arr[j+1].flight_duration))
              SwapFlights(&arr[j], &arr[j+1]);
}

/* ------- Functions For Departing and Arriving Flight  ------- */

void FlightListSelector(Flight FlightST[],Flight TempFlightST[],
        unsigned int flight_count,char airport_id[], char flag){

    unsigned int counter,counter1;
    char * temp_airport_id;

    for (counter = 0,counter1 = 0; counter < flight_count; counter++){
        if(flag == 'd'){
            temp_airport_id = FlightST[counter].airport_departure;
        }else if(flag == 'a'){
            temp_airport_id = FlightST[counter].airport_arrival;
        }
        if(!strcmp(temp_airport_id,airport_id)){
                TempFlightST[counter1] = FlightST[counter];
                counter1 ++;
        }
}
}


void ListDepartingOrArrivingFlights(Airport AirportST[],Flight FlightST[],
        unsigned int airport_count, int flight_count,char flag){
    unsigned int counter,num_flights;

    Flight TempFlightST[MAX_FLIGHTS];
    int airport_id_position;
    char temp_airport_id[AIRPORT_ID];
    
    scanf("%s",temp_airport_id);
    airport_id_position = AirportIDFinder(AirportST,temp_airport_id,airport_count);
    if(airport_id_position == -1){
        return;
    }

    if(flag == 'd'){
        num_flights = AirportST[airport_id_position].num_flights_departing;

        FlightListSelector(FlightST,TempFlightST,flight_count,temp_airport_id,flag);

        DepartingFlightsSorter(TempFlightST,num_flights);

        for (counter = 0; counter < num_flights; counter++){
            printf("%s %s ",TempFlightST[counter].flight_code,TempFlightST[counter].airport_arrival);
            PrintTimeStamp(TempFlightST[counter].datetime,'m');
        }
    } else if(flag == 'a'){
        num_flights = AirportST[airport_id_position].num_flights_arriving;

        FlightListSelector(FlightST,TempFlightST,flight_count,temp_airport_id,flag);

        ArrivingFlightsSorter(TempFlightST,num_flights);
        
        for (counter = 0; counter < num_flights; counter++){
        printf("%s %s ",TempFlightST[counter].flight_code,TempFlightST[counter].airport_departure);
        PrintTimeStamp(TempFlightST[counter].datetime+TempFlightST[counter].flight_duration,'m');
        }
    }
}
