#include <stdio.h>

typedef unsigned int uint;

uint DateTimeToTimeStamp(uint day, uint month, uint year, uint min, uint hour){
    uint timestamp;
    timestamp = year * 360 * 24 * 60;
    if(month == 2){
        timestamp += 28 * 24 * 60;
    } else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 9){
        timestamp += 31 * 24 * 60;
    } else{
        timestamp += 30 * 24 * 60;
    }
    timestamp += day * 24 * 60;
    timestamp += hour * 60; 
    timestamp += min; 
    return timestamp;
}

void PrintTimeStamp(uint timestamp){
    
}



int main()
{
    /* code */
    return 0;
}
