/*
 * File:    proj1.c
 * Author:  Daniel Martins Pão Alvo (ist1102914)
 * Email:   daniel.martins.22@tecnico.ulisboa.pt
 * Description: An attempt at making an airport and flight management system.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define AIRPORT_ID 4 
#define COUNTRY_NAME_SIZE 31
#define CITY_NAME_SIZE 51

#define FLIGHT_CODE 7

#define VALID_FLIGHT_DURATION 12
#define FLIGHT_CAPACITY_MIN 10
#define FLIGHT_CAPACITY_MAX 100

#define MAX_AIRPORTS 40
#define MAX_FLIGHTS 30000

#define CONV_DAY_TO_MIN 1440
#define CONV_MONTH_TO_MIN 43800
#define CONV_YEAR_TO_MIN 525600

typedef struct{
    unsigned min;
    unsigned hour;
    unsigned day;
    unsigned month;
    unsigned year;
}DateTime;

typedef struct {
    char id[AIRPORT_ID];
    char country[COUNTRY_NAME_SIZE];
    char city[CITY_NAME_SIZE];
    int num_flights_departing;
    int num_flights_arriving;
}Airport;

typedef struct {
    char flight_code[FLIGHT_CODE];
    char airport_departure[AIRPORT_ID];
    char airport_arrival[AIRPORT_ID];
    DateTime DateTime;
    unsigned int date;
    unsigned int time;
    unsigned int flight_duration;
    unsigned int flight_duration_hour;
    unsigned int flight_duration_min;
    unsigned int flight_capacity;
}Flight;

/* ----- Date and Time Functions ----- */

unsigned int DateToTimeStamp(unsigned int day,unsigned int month, unsigned int year){
    return ((day)*CONV_DAY_TO_MIN)+((month)*CONV_MONTH_TO_MIN)+((year)*CONV_YEAR_TO_MIN);
}

unsigned int TimeToTimeStamp(unsigned int min,unsigned int hour){
    return min+(hour*60); 
}

unsigned int TimeStampToDate(unsigned int time_stamp){
    unsigned int year,month,day,time;
    year = time_stamp/CONV_YEAR_TO_MIN;
    month = (time_stamp-(CONV_YEAR_TO_MIN*year))/CONV_MONTH_TO_MIN; 
    day = (time_stamp-((CONV_YEAR_TO_MIN*year)+(CONV_MONTH_TO_MIN*month)))/CONV_DAY_TO_MIN;
    time = (time_stamp-((CONV_YEAR_TO_MIN*year)+(CONV_MONTH_TO_MIN*month)+(CONV_DAY_TO_MIN*day)));
    if(!day){
        month -= 1;
        day += 31;
    }
    if(!month){
        year -= 1;
        month += 12;
    }
    if(month == 2 && day == 29){
        month += 1;
        day = 1;
    }
    printf("%02u-%02u-%04u",day,month,year);
    return time;
}

void TimeStampToHour(int time_stamp){
    unsigned int min, hour;
    hour = time_stamp/60;
    min = time_stamp - (hour*60);
    printf("%02u:%02u",hour,min);
}

void DateAdder(Flight FlightST[],int flight_position){
    unsigned int min,hour,day,month,year;

    min =  FlightST[flight_position].DateTime.min + FlightST[flight_position].flight_duration_min;
    hour = FlightST[flight_position].DateTime.hour + FlightST[flight_position].flight_duration_hour;
    day = FlightST[flight_position].DateTime.day;
    month = FlightST[flight_position].DateTime.month;
    year = FlightST[flight_position].DateTime.year;

    if(min >= 60){
        hour += 1;
        min %= 60;
    }if(hour >= 24){
        day += 1;
        hour %= 24;
    }if(month == 2 && day > 28){
        month += 1;
        day =1;
    }if(day > 30){
        month += 1;
        day = 1;
    }if(month > 12){
        year += 1;
        month -= 12;
        day = 1;
    }
    printf("%02u-%02d-%04d %02u:%02u\n",day,month,year,hour,min);
}

unsigned int DateAdvancer(unsigned int curent_date){
    unsigned int day,month,year,timestamp;
    scanf("%u-%u-%u",&day,&month,&year);
    timestamp = DateToTimeStamp(day,month,year);
    if (timestamp > (curent_date+CONV_YEAR_TO_MIN) || timestamp < curent_date){
        printf("invalid date\n");
        return curent_date;
    }
    
    TimeStampToDate(timestamp);
    printf("\n");
    return timestamp;
}

/* ----- Airport Error Functions ----- */

int ValidAirportID(char id[]){
    int counter;
    for (counter = 0; counter < AIRPORT_ID-1; counter++){
        if(!isupper(id[counter])){
            printf("invalid airport ID\n");
            return 0;
        }
    }
    return 1;
}

int MAXAirports(int airport_count){
    if (airport_count == MAX_AIRPORTS){
        printf("too many airports\n");
        return 1;
    }
    return 0;
}

int DuplicateAirport(Airport AirportST[],char id[],int airport_count){
    int counter;
    for (counter = 0; counter < airport_count; counter++){
        if(!strcmp(AirportST[counter].id,id)){
            printf("duplicate airport\n");
            return 1;
        }
    }
    return 0;
}

int GenericAirportErrorHandler(Airport AirportST[],char temp_id[],int airport_count){
    return ValidAirportID(temp_id) && !MAXAirports(airport_count) 
        && !DuplicateAirport(AirportST,temp_id,airport_count);
}

/* -------- Airport Functions ------- */

void SortsAirports(Airport arr[], int n){
	int i,j;
    Airport key;

    for (i = 0; i < n; i++) {
        key = arr[i];
        j = i - 1;
			while (j >= 0 && strcmp(arr[j].id,key.id) > 0){
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = key;
    }
}

int AirportAdder(Airport AirportST[],int airport_count){
    char temp_id[AIRPORT_ID], temp_country[COUNTRY_NAME_SIZE],
         temp_city[CITY_NAME_SIZE];

    scanf("%s %s %[^\n]s",temp_id,temp_country,temp_city);

    if(GenericAirportErrorHandler(AirportST,temp_id,airport_count)){
        strcpy(AirportST[airport_count].id,temp_id);
        strcpy(AirportST[airport_count].country,temp_country);
        strcpy(AirportST[airport_count].city,temp_city);
        AirportST[airport_count].num_flights_departing = 0;
        AirportST[airport_count].num_flights_arriving = 0;
        
        SortsAirports(AirportST,airport_count);
        
        printf("airport %s\n",AirportST[airport_count].id); 
        return 1;
    } 
    return 0;
}

/* ----- Lists Airport Functions ----- */

void AirportPrinter(Airport AirportST){
    printf("%s %s %s %d\n",AirportST.id,AirportST.city,
        AirportST.country,AirportST.num_flights_departing);
}

void ListAirport(Airport AirportST[],int airport_count){
    char temp_airportID[AIRPORT_ID];
    unsigned char temp_val;
    int counter;

    SortsAirports(AirportST,airport_count);

    temp_val = getchar();
    if(temp_val == '\n'){
        for (counter = 0; counter < airport_count; counter++){
        AirportPrinter(AirportST[counter]);
        } 
    } else {
        while (temp_val != '\n'){
            scanf("%s",temp_airportID);
            for (counter = 0; counter < airport_count; counter++){
                if(!strcmp(temp_airportID,AirportST[counter].id)){
                    AirportPrinter(AirportST[counter]);
                    break;
                }
                if(counter == airport_count - 1){
                    printf("%s: no such airport ID\n",temp_airportID);
                    break;
                }
            }
            temp_val = getchar();
        }
    }
}

/* ----- Flight Error Functions ----- */

int FlightCodeVerifer(char flight_code[]){
    int counter;
    unsigned char num_of_letters = 2;
    for (counter = 0; counter < FLIGHT_CODE; counter++){
        if(flight_code[counter] == '\0'){
            break;
        }
        if(counter<num_of_letters){
            if(!isupper(flight_code[counter])){
                printf("invalid flight code\n");
                return 0;
            }
        }else{
            if(!isdigit(flight_code[counter]) || flight_code[2] == '0'){
                printf("invalid flight code\n");
                return 0;
                }            
        }
    } 
    return 1;
}

int FlightExists(Flight FlightST[],char flight_code[],unsigned int date_ref,
    int flight_count){
    int counter;
    for (counter = 0; counter < flight_count; counter++){
        if(!strcmp(FlightST[counter].flight_code,flight_code) 
            && FlightST[counter].date == date_ref){
                printf("flight already exists\n");
                return 1;
            }
    }
    return 0;
}

int ValidAirport(Airport AirportST[],char airport_ID[],int airport_count,char flag){
    int counter;
    for (counter = 0; counter < airport_count; counter++){
        if(!strcmp(AirportST[counter].id,airport_ID)){
            /*Increments number of flights from the departing*/
            if(flag == 'd'){
                AirportST[counter].num_flights_departing +=1;
            }
            else if(flag == 'a'){
                AirportST[counter].num_flights_arriving +=1;
            }
            return 1;
        }
    }
    printf("%s: no such airport ID\n",airport_ID);
    return 0;
}

int MAXFlights(int flight_count){
    if(flight_count == MAX_FLIGHTS){
        printf("too many flights\n");
        return 1;
    }
    return 0;
}

int ValidFlightDate(unsigned int current_date,unsigned int date_ref){
    if(current_date <= date_ref && date_ref <= (current_date + CONV_YEAR_TO_MIN)){
        return 1;
    }
    printf("invalid date\n");
    return 0;
}

int ValidDuration(unsigned int duration){
    if(duration > (VALID_FLIGHT_DURATION * 60)){
        printf("invalid duration\n");
        return 0;
    }
    return 1;
}

int ValidCapacity(unsigned int capacity){
    if(capacity >= FLIGHT_CAPACITY_MIN && capacity <= FLIGHT_CAPACITY_MAX){
        return 1;
    }
    printf("invalid capacity\n");
    return 0;
}

int GenericFlightErrorHandler(Airport AirportST[], Flight FlightST[],char temp_flight_code[],
    unsigned int temp_date_ref,unsigned int temp_duration_ref,unsigned int flight_count,
    unsigned int airport_count,char temp_airport_departure[],char temp_airport_arrival[],
    unsigned int current_date, unsigned int temp_capacity){
    
    return FlightCodeVerifer(temp_flight_code) &&
        !FlightExists(FlightST,temp_flight_code,temp_date_ref,flight_count) &&
        ValidAirport(AirportST,temp_airport_departure,airport_count,'d') &&
        ValidAirport(AirportST,temp_airport_arrival,airport_count,'a') &&
        !MAXFlights(flight_count) &&
        ValidFlightDate(current_date,temp_date_ref) &&
        ValidDuration(temp_duration_ref) &&
        ValidCapacity(temp_capacity);

}

/* ------- Flight Functions ------- */

void FlightPrinter(Flight FlightST){
    printf("%s %s %s ",FlightST.flight_code,FlightST.airport_departure,FlightST.airport_arrival);
    TimeStampToDate(FlightST.date);
    printf(" ");
    TimeStampToHour(FlightST.time);
    printf("\n");
}

void ListFlights(Flight FlightST[],unsigned int flight_count){
    unsigned int counter;
    for (counter = 0; counter < flight_count; counter++){
            FlightPrinter(FlightST[counter]);
    }
}

int FlightAdder(Airport AirportST[], Flight FlightST[],unsigned int current_date,
        unsigned int airport_count,unsigned int flight_count){
    char temp_flight_code[FLIGHT_CODE], temp_airport_departure[AIRPORT_ID],
        temp_airport_arrival[AIRPORT_ID],mode;

    unsigned int temp_date_ref,temp_time_ref,temp_duration_ref,
            temp_day, temp_month, temp_year,
            temp_hour, temp_min,
            temp_duration_hour, temp_duration_min, temp_capacity;

    if((mode = getchar()) == '\n'){
        ListFlights(FlightST,flight_count);
        return 0;
    }

    scanf("%s %s %s",temp_flight_code, temp_airport_departure, temp_airport_arrival);
    scanf("%u-%u-%u %u:%u",&temp_day, &temp_month, &temp_year,&temp_hour,&temp_min);
    scanf("%u:%u %u",&temp_duration_hour, &temp_duration_min, &temp_capacity);

    temp_date_ref = DateToTimeStamp(temp_day,temp_month,temp_year);
    temp_time_ref = TimeToTimeStamp(temp_min,temp_hour);
    temp_duration_ref = TimeToTimeStamp(temp_duration_min,temp_duration_hour);

    if (GenericFlightErrorHandler(AirportST,FlightST,temp_flight_code,temp_date_ref,
            temp_duration_ref,flight_count,airport_count,temp_airport_departure,
            temp_airport_arrival,current_date,temp_capacity)){
            
            /* Copies Temp Flight Data over to Flight Array */
            strcpy(FlightST[flight_count].flight_code,temp_flight_code);
            strcpy(FlightST[flight_count].airport_departure,temp_airport_departure);
            strcpy(FlightST[flight_count].airport_arrival,temp_airport_arrival);

            FlightST[flight_count].DateTime.min = temp_min;
            FlightST[flight_count].DateTime.hour = temp_hour;
            FlightST[flight_count].DateTime.day = temp_day;
            FlightST[flight_count].DateTime.month = temp_month;
            FlightST[flight_count].DateTime.year = temp_year;
            FlightST[flight_count].flight_duration_min = temp_duration_min;
            FlightST[flight_count].flight_duration_hour = temp_duration_hour;

            FlightST[flight_count].date = temp_date_ref;
            FlightST[flight_count].time = temp_time_ref;
            FlightST[flight_count].flight_duration = temp_duration_ref;
            FlightST[flight_count].flight_capacity = temp_capacity;

            return 1;
    } else {
        return 0;
    }
}

/* ------- Flight Functions ------- */

int AirportIDFinder(Airport AirportST[],char airport_id[],
        unsigned int airport_count){
    unsigned int counter;
    for (counter = 0; counter < airport_count; counter++){
        if(!strcmp(AirportST[counter].id,airport_id)){
            return counter;
        }
    }
    printf("%s: no such airport ID\n",airport_id);
    return -1;
}

void SwapFlights(Flight *xp, Flight *yp){
    Flight temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void DepartingFlightsSorter(Flight arr[], int n){
    int i, j;
     for (i = 0; i < n-1; i++){     
        for (j = 0; j < n-i-1; j++){
            if ((arr[j].date+arr[j].time) > (arr[j+1].date+arr[j+1].time)){
                SwapFlights(&arr[j], &arr[j+1]);
            }
        }
    }
}

void ArrivingFlightsSorter(Flight arr[], int n){
   int i, j;
   for (i = 0; i < n-1; i++)     
       for (j = 0; j < n-i-1; j++)
           if ((arr[j].date + arr[j].time + arr[j].flight_duration) > (arr[j+1].date + arr[j+1].time + arr[j+1].flight_duration))
              SwapFlights(&arr[j], &arr[j+1]);
}

/* ------- Functions For Departing and Arriving Flight  ------- */

void ListDepartingFlights(Airport AirportST[],Flight FlightST[],
        unsigned int airport_count,unsigned int flight_count){
    unsigned int counter,counter2,counter3,num_flights;
    Flight TempFlightST[MAX_FLIGHTS];
    int airport_id_position;
    char temp_departing_airport_id[AIRPORT_ID];
    
    scanf("%s",temp_departing_airport_id);
    airport_id_position = AirportIDFinder(AirportST,temp_departing_airport_id,airport_count);
    if(airport_id_position == -1){
        return;
    }

    num_flights = AirportST[airport_id_position].num_flights_departing;

    
    for (counter = 0,counter3 = 0; counter < flight_count; counter++){
        if(!strcmp(FlightST[counter].airport_departure,temp_departing_airport_id)){
                TempFlightST[counter3] = FlightST[counter];
                counter3 ++;
        }
    }

    DepartingFlightsSorter(TempFlightST,num_flights);

    for (counter2 = 0; counter2 < num_flights; counter2++){
        printf("%s %s ",TempFlightST[counter2].flight_code,TempFlightST[counter2].airport_arrival);
        TimeStampToDate(TempFlightST[counter2].date);
        printf(" ");
        TimeStampToHour(TempFlightST[counter2].time);
        printf("\n");
    }
}

void ListArrivingFlights(Airport AirportST[],Flight FlightST[],
        unsigned int airport_count,unsigned int flight_count){
    unsigned int counter,counter2,counter3,num_flights;
    Flight TempFlightST[MAX_FLIGHTS];
    char temp_arriving_airport_id[AIRPORT_ID];
    int airport_id_position;

    scanf("%s",temp_arriving_airport_id);

    airport_id_position = AirportIDFinder(AirportST,temp_arriving_airport_id,airport_count);
    if(airport_id_position == -1){
        return;
    }
    num_flights = AirportST[airport_id_position].num_flights_arriving;

    for (counter = 0,counter3 = 0; counter < flight_count; counter++){
        if(!strcmp(FlightST[counter].airport_arrival,temp_arriving_airport_id)){
                TempFlightST[counter3] = FlightST[counter];
                counter3 ++;
        }
    }

    ArrivingFlightsSorter(TempFlightST,num_flights);
    
    for (counter2 = 0; counter2 < num_flights; counter2++){
    printf("%s %s ",TempFlightST[counter2].flight_code,TempFlightST[counter2].airport_departure);
    DateAdder(TempFlightST,counter2);
    }

}

/* ------------------------------------------------------------ */

int main(){
    unsigned char command;
    unsigned int airport_count = 0,flight_count = 0;

    int SystemDate = DateToTimeStamp(1,1,2022);
    Airport SystemAirports[MAX_AIRPORTS];
    Flight SystemFlights[MAX_FLIGHTS];

    while ((command = getchar()) != 'q')
    {
        switch (command){
        case 'a':   /*  Adds New Airport  */
            if(AirportAdder(SystemAirports,airport_count)){
                airport_count += 1;
            };
            break;
        case 'l':   /*  List Airports Recorded  */
            ListAirport(SystemAirports,airport_count);
            break;
        case 'v':   /*  Adds New Flight  */
            if(FlightAdder(SystemAirports,SystemFlights,SystemDate,airport_count,flight_count)){
                flight_count += 1;
            }
            break;
        case 'p':    /*  Lists Flights Departing from an Airport  */
            ListDepartingFlights(SystemAirports,SystemFlights,airport_count,flight_count);
            break;
        case 'c':   /*  lists flights Arriving at an airport  */
            ListArrivingFlights(SystemAirports,SystemFlights,airport_count,flight_count);
            break;
        case 't':   /*  Advance the System Date  */
            SystemDate = DateAdvancer(SystemDate);
            break;
        default:
            break;
        }
    }
    return 0;
}
