#include <stdio.h>


long DateTimeToTimeStamp(long year,long month,long day,
        long hour,long minutes,long seconds){

    long timestamp;
    if(month <= 2){
        month += 12;
        year -= 1;
    }
    timestamp = (365 * year) + (year / 4) - (year / 100) + (year / 400);
    timestamp += (30 * month) + (3 * (month + 1) / 5) + day;
    timestamp -= 719561;
    timestamp *= 86400;
    
    timestamp += (3600 * hour) + (60 * minutes) + seconds;
    return timestamp;
} 

void TimeStampToDateTime(long timestamp,char flag){
    long seconds,minutes,hour,day,month,year;
    long a,b,c,d,e,f;

    seconds = timestamp % 60;
    timestamp /= 60;

    minutes = timestamp % 60;
    timestamp /= 60;

    hour = timestamp % 24;
    timestamp /= 24;

    a = (long) ((4 * timestamp + 102032) / 146097 + 15);
    b = (long) (timestamp + 2442113 + a - (a / 4));
    c = (20 * b - 2442) / 7305;
    d = b - 365 * c - (c / 4);
    e = d * 1000 / 30601;
    f = d - e * 30 - e * 601 / 1000;

    if(e <= 13){
        c -= 4716;
        e -= 1;
    } else {
        c -= 4715;
        e -= 13;
    }

    year = c;
    month = e;
    day = f;

    if(flag == 'a'){
        printf("%02lu-%02ld-%04ld %02lu:%02lu:%02lu\n",day,month,year,hour,minutes,seconds);
    } else if(flag == 'd'){
        printf("%02lu-%02ld-%04ld\n",day,month,year);
    } else if(flag == 't'){
        printf("%02lu:%02lu\n",hour,minutes);
    } else if(flag == 'p'){
        printf("%02lu-%02ld-%04ld %02lu:%02lu\n",day,month,year,hour,minutes);
    }
} 

int main(){
    long temp,temp2;
    temp = DateTimeToTimeStamp(2022,3,23,13,10,0);
    temp2 = DateTimeToTimeStamp(2012,0,0,0,0,0);
    TimeStampToDateTime(temp+temp2,'p');
    return 0;
}
