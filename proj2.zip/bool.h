/*-*-coding:utf-8 -*- 
 *Auto updated?
 *   Yes
 *File :
 *   bool.h
 *Author :
 *   Daniel Martins Pão Alvo
 *
 *Created:
 *   April 19, 2022, 11:22:03 PM GMT+1
 *Last edited:
 *   April 19, 2022, 11:22:13 PM GMT+1
 *
 *Description:
 *   Definition of basic Bool.
 *
 *Dependencies:
 *   <None>
**/

/* Definition of bool.*/
#define TRUE 1
#define FALSE 0
